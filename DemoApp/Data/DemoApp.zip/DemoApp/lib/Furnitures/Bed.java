Class Bed{

Public static void main (string [] args){
      int Beds =2
      int Blankets =2 


}

}