Class Chair{

Public satic void main (string [] args)
{

   int chairs =2;
   String ChairColourOne ="Red"
   String ChairColourTwo ="Blue"

}

}