Class Flist 
{
public static void maid (String [] args)

{
    FList ListFurnit= New FList();
                  
          
}

            int add()
           {

            }


}